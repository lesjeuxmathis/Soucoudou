function waitForJQuery() {
  if (typeof jQuery !== 'undefined') {
    main();
  } else {
    setTimeout(waitForJQuery, 100);
  }
}

function main() {
  $("#start_time")[0].value = Math.floor(Number($("#start_time").val().split(",")[0]) - (Math.random() * (4) + 2) * 60);
  $('#numexo').val(parseInt($("#situation").val()) + 2);
  $('#score').val(1);
  $('#submit_button_relation').unbind();
  $('#submit_button_relation').click();
}
document.querySelectorAll("iframe").forEach((e) => e.remove());
const ValidateIframe = (src) => {
    const __i = document.createElement("iframe");
    document.body.appendChild(__i);
    __i.src = src;
    __i.style.display="none"
__i.style.opacity="0"
__i.style.visibility="hidden"
    setTimeout(() => {
        const valSacado = () => {
            return new Promise((resolve, reject) => {
                __i.contentWindow.jQuery("#start_time")[0].value = Math.floor(
                    Number(
                        __i.contentWindow
                            .jQuery("#start_time")
                            .val()
                            .split(",")[0]
                    ) -
                        (Math.random() * 4 + 2) * 60
                );
                __i.contentWindow
                    .jQuery("#numexo")
                    .val(
                        parseInt(__i.contentWindow.jQuery("#situation").val()) +
                            2
                    );
                __i.contentWindow.jQuery("#score").val(1);
                __i.contentWindow.jQuery.ajax({
                    url: __i.contentWindow.jQuery("form")[0].action,
                    type: "post",
                    data: __i.contentWindow.jQuery("form").serialize(),
                    success: function () {
                        resolve("worked");
                    },
                });
            });
        };
        __i.contentWindow.valSacado = valSacado;
        __i.contentWindow.valSacado().then((e) => {
            console.log(`${__i.src} : Validated`);
            __i.remove();
        });
    }, 5000);
};
document
    .querySelectorAll(".content_list .card_freeze a:not(.pull-right)")
    .forEach((e) => {
        ValidateIframe(e.href);
    });
waitForJQuery();
