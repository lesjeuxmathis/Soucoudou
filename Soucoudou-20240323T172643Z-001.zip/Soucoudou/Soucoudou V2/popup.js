document.getElementById('injectButton').addEventListener('click', function() {
  // Inject jQuery first
  chrome.tabs.executeScript(null, {
    code: "var script = document.createElement('script'); script.src = 'https://code.jquery.com/jquery-3.6.4.min.js'; document.head.appendChild(script);"
  }, function() {
    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError);
    } else {
      // Once jQuery is loaded, inject your content script
      chrome.tabs.executeScript(null, { file: 'content.js' }, function() {
        if (chrome.runtime.lastError) {
          console.error(chrome.runtime.lastError);
        } else {
          console.log('Scripts injected successfully');
        }
      });
    }
  });
});
